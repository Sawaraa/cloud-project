export const defaultPage = 'default';
export const login = 'login';
export const secretPage = 'secret';
export const books = 'books'
export const formCreate = 'formCreate';


export { default } from './CardContent';

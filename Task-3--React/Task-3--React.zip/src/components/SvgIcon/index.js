export { default } from '@mui/material/SvgIcon';

export { default } from './IntlProvider';

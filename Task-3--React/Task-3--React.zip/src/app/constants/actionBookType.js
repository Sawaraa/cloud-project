// Book
export const REQUEST_BOOKS = 'REQUEST_BOOKS'; // Почали завантаження (показуємо спінер)
export const RECEIVE_BOOKS = 'RECEIVE_BOOKS'; // Отримали дані (ховаємо спінер, записуємо книги)
export const ERROR_BOOKS = 'ERROR_BOOKS';     // Щось пішло не так